export interface ConfidenceParams {
  tier: number; // 0, 1, 2, 3
  stage: 'OFFICIAL' | 'DONE' | 'ADVANCED' | 'INTEREST' | 'RUMOR';
  sourceCount: number;
  isCertainLanguage: boolean;
}

export function calculateConfidenceScore(params: ConfidenceParams): number {
  let score = 0;

  // 1. Kaynak Tier Puanı (Max 35)
  if (params.tier === 0) score += 35;
  else if (params.tier === 1) score += 25;
  else if (params.tier === 2) score += 15;
  else score += 5;

  // 2. Transfer Aşaması (Max 30)
  switch (params.stage) {
    case 'OFFICIAL':
    case 'DONE':
      score += 30;
      break;
    case 'ADVANCED':
      score += 20;
      break;
    case 'INTEREST':
      score += 10;
      break;
    case 'RUMOR':
    default:
      score += 0;
      break;
  }

  // 3. Çapraz Doğrulama (Max 25)
  if (params.sourceCount >= 3) score += 25;
  else if (params.sourceCount === 2) score += 15;

  // 4. Dil Kesinliği (Max 10)
  if (params.isCertainLanguage) score += 10;

  // Tier 0 resmi haber bonusu
  if (params.tier === 0) return 100;

  return Math.min(score, 99);
}
