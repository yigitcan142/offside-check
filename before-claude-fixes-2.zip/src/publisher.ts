import 'dotenv/config';
import { AIResult } from './prompts.js';

interface PublishedStory {
  messageId: number;
  createdAt: number;
  text: string;
  sources: Set<string>;
}

const publishedStories = new Map<string, PublishedStory>();
const STORY_WINDOW_MS = 12 * 60 * 60 * 1000;

export function generateStoryKey(analysis: AIResult): string {
  const subject = analysis.subjectName || 'unknown';
  const club = analysis.primaryClub || analysis.toClub || analysis.fromClub || 'unknown';
  return [analysis.category, subject, club]
    .map((value) => value.trim().toLocaleLowerCase('tr-TR').replace(/\s+/g, '_'))
    .join('_');
}

async function telegramRequest(token: string, method: string, body: Record<string, unknown>): Promise<any> {
  const response = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (!response.ok) {
    throw new Error(`Telegram API ${response.status}: ${await response.text()}`);
  }

  const payload = await response.json() as { ok: boolean; result?: any; description?: string };
  if (!payload.ok) {
    throw new Error(payload.description || `Telegram ${method} failed.`);
  }
  return payload.result;
}

export async function sendTelegramMessage(
  text: string,
  analysis?: AIResult,
  sourceLine?: string
): Promise<boolean> {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  try {
    if (!token || !chatId) {
      throw new Error('TELEGRAM_BOT_TOKEN or TELEGRAM_CHAT_ID is not defined.');
    }

    if (!analysis) {
      await telegramRequest(token, 'sendMessage', {
        chat_id: chatId,
        text,
        parse_mode: 'HTML',
        link_preview_options: { is_disabled: true }
      });
      console.log('[Telegram] Mesaj kanala iletildi.');
      return true;
    }

    const now = Date.now();
    for (const [key, story] of publishedStories) {
      if (now - story.createdAt > STORY_WINDOW_MS) {
        publishedStories.delete(key);
      }
    }

    const storyKey = generateStoryKey(analysis);
    const source = sourceLine || '';
    const existing = publishedStories.get(storyKey);
    if (existing && source && !existing.sources.has(source)) {
      existing.sources.add(source);
      existing.text = `${existing.text}\n${source}`;
      await telegramRequest(token, 'editMessageText', {
        chat_id: chatId,
        message_id: existing.messageId,
        text: existing.text,
        parse_mode: 'HTML',
        link_preview_options: { is_disabled: true }
      });
      console.log(`[Telegram] Mükerrer haber güncellendi: ${storyKey}`);
      return true;
    }

    if (existing) {
      return true;
    }

    const message = await telegramRequest(token, 'sendMessage', {
      chat_id: chatId,
      text,
      parse_mode: 'HTML',
      link_preview_options: { is_disabled: true }
    });
    publishedStories.set(storyKey, {
      messageId: message.message_id,
      createdAt: now,
      text,
      sources: new Set(source ? [source] : [])
    });
    console.log('[Telegram] Mesaj kanala iletildi.');
    return true;
  } catch (error: any) {
    console.error('[Telegram] Mesaj gönderilemedi:', error.message);
    return false;
  }
}