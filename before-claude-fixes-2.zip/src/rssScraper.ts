import Parser from 'rss-parser';

const parser = new Parser({
  headers: {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
  },
  timeout: 10000
});

export interface RssItem {
  id: string;
  title: string;
  content: string;
  url: string;
  sourceName: string;
  tier: number;
  pubDate?: string;
}

// Resmi RSS / Haber Akışları
const RSS_FEEDS = [
  {
    name: 'KAP (Kamuyu Aydınlatma Platformu)',
    url: 'https://www.kap.org.tr/tr/api/rss',
    tier: 0
  },
  {
    name: 'TFF Resmi Duyurular',
    url: 'https://www.tff.org/rss/rss.aspx?id=1',
    tier: 0
  },
  {
    name: 'Galatasaray SK Resmi',
    url: 'https://www.galatasaray.org/rss',
    tier: 0
  },
  {
    name: 'Fenerbahçe SK Resmi',
    url: 'https://www.fenerbahce.org/rss/fenerbahce-haberleri.xml',
    tier: 0
  },
  {
    name: 'Beşiktaş JK Resmi',
    url: 'https://bjk.com.tr/tr/rss',
    tier: 0
  },
  {
    name: 'Trabzonspor Resmi',
    url: 'https://www.trabzonspor.org.tr/rss',
    tier: 0
  }
];

// İşlenmiş haberleri bellekte tutmak için (Son 1000 haber ID)
const processedRssIds = new Set<string>();

export async function fetchOfficialNews(): Promise<RssItem[]> {
  const newItems: RssItem[] = [];

  for (const feed of RSS_FEEDS) {
    try {
      const feedData = await parser.parseURL(feed.url);

      for (const item of feedData.items || []) {
        const itemId = item.guid || item.link || item.title || '';

        if (!itemId || processedRssIds.has(itemId)) {
          continue;
        }

        // Son 3 saatin haberlerini al
        const pubDate = item.pubDate ? new Date(item.pubDate).getTime() : Date.now();
        const hoursAgo = (Date.now() - pubDate) / (1000 * 60 * 60);

        if (hoursAgo <= 3) {
          processedRssIds.add(itemId);
          if (processedRssIds.size > 1000) {
            const firstKey = processedRssIds.values().next().value;
            if (firstKey) processedRssIds.delete(firstKey);
          }

          newItems.push({
            id: itemId,
            title: item.title || '',
            content: item.contentSnippet || item.content || item.title || '',
            url: item.link || '',
            sourceName: feed.name,
            tier: feed.tier,
            pubDate: item.pubDate
          });
        }
      }
    } catch (err) {
      // Bireysel RSS patlarsa ana akış kesilmesin
      console.warn(`[RSS HATA] ${feed.name} çekilemedi:`, (err as Error).message);
    }
  }

  return newItems;
}
