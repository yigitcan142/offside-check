import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const geminiApiKey = process.env.GEMINI_API_KEY;
const aiModelName = process.env.AI_MODEL_NAME;

if (!geminiApiKey) {
  throw new Error('GEMINI_API_KEY is not defined. Add it to the project root .env file.');
}

if (!aiModelName) {
  throw new Error('AI_MODEL_NAME is not defined. Add it to the project root .env file.');
}

const ai = new GoogleGenAI({ apiKey: geminiApiKey });
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

export type BatchCategory = 'transfer' | 'injury' | 'lineup' | 'official_statement' | 'noise';

export interface BatchAnalysis {
  id: string;
  is_news: boolean;
  category: BatchCategory;
  summaryTr: string;
}

export interface TweetBatchInput {
  id: string;
  text: string;
}

const responseSchema = {
  type: Type.ARRAY,
  items: {
    type: Type.OBJECT,
    properties: {
      id: { type: Type.STRING },
      is_news: { type: Type.BOOLEAN },
      category: {
        type: Type.STRING,
        enum: ['transfer', 'injury', 'lineup', 'official_statement', 'noise']
      },
      summaryTr: { type: Type.STRING }
    },
    required: ['id', 'is_news', 'category', 'summaryTr']
  }
};

const BATCH_SYSTEM_PROMPT = `You analyze batches of football tweets and return ONLY a JSON array matching the requested schema.
For every tweet, decide whether it contains concrete football news: transfer, injury, lineup/squad status, official statement, contract update, training update, or another factual football development.
Return is_news: true for concrete news. Return is_news: false for match-time fan comments, personal jokes, opinions, advertisements, promotions, unrelated content, or noise.
Use category transfer, injury, lineup, official_statement, or noise. Keep summaryTr short and in Turkish. Include exactly one result for every input tweet, preserving its id. Do not add markdown or extra fields.`;

export async function analyzeTweetsBatch(tweets: TweetBatchInput[]): Promise<BatchAnalysis[]> {
  console.log(`[GEMINI] Batch size: ${tweets.length}`);

  if (tweets.length === 0) {
    return [];
  }

  try {
    const contents = `Analyze these tweets as a batch:\n${JSON.stringify(tweets)}`;
    let response;
    for (let attempt = 0; attempt < 2; attempt += 1) {
      try {
        response = await ai.models.generateContent({
          model: aiModelName,
          contents: [
            { role: 'user', parts: [{ text: `${BATCH_SYSTEM_PROMPT}\n\n${contents}` }] }
          ],
          config: {
            responseMimeType: 'application/json',
            responseSchema
          }
        });
        break;
      } catch (error: any) {
        if (attempt > 0) {
          throw error;
        }
        await sleep(1000);
      }
    }

    const rawText = response?.text?.trim();
    if (!rawText) {
      return [];
    }

    const parsed = JSON.parse(rawText) as BatchAnalysis[];
    return parsed.filter((item) => tweets.some((tweet) => tweet.id === item.id));
  } catch (error: any) {
    console.error('Gemini batch analysis error:', error.message);
    return [];
  }
}

export function logGeminiSessionCost(): void {
  console.log('[Gemini] Batch analiz tamamlandı.');
}
