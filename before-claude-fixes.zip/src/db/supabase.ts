import { createClient, SupabaseClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';
import path from 'path';
import { ScrapedTweet } from '../scraper/twitter.js';
import { analyzeTweetsBatch, BatchAnalysis } from '../ai/analyzer.js';
import { AIResult } from '../prompts.js';

const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));
const ANALYSIS_DELAY_MS = 13_000;
const DEFAULT_ANALYSIS_LIMIT = 10;

function toAnalysisResult(result: BatchAnalysis): AIResult {
  const categoryMap: Record<BatchAnalysis['category'], AIResult['category']> = {
    transfer: 'TRANSFER',
    injury: 'INJURY',
    lineup: 'SQUAD_STATUS',
    official_statement: 'MANAGER_STAFF',
    noise: 'MANAGER_STAFF'
  };

  return {
    is_news: result.is_news,
    category: categoryMap[result.category],
    isActionable: result.is_news,
    confidenceScore: result.is_news ? 100 : 0,
    isBreaking: false,
    subjectName: result.is_news ? 'Haber' : null,
    subjectRole: 'Yönetici',
    fromClub: null,
    toClub: null,
    primaryClub: null,
    statusDescription: result.summaryTr,
    summaryTr: result.summaryTr
  };
}

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY || process.env.SUPABASE_ANON_KEY;

if (!supabaseUrl) {
  throw new Error('SUPABASE_URL is not defined. Add it to the project root .env file.');
}

if (!supabaseKey) {
  throw new Error('SUPABASE_SERVICE_ROLE_KEY or SUPABASE_ANON_KEY is not defined. Add one to the project root .env file.');
}

export const supabase: SupabaseClient = createClient(supabaseUrl, supabaseKey);
type SourceColumn = 'screen_name' | 'handle';

function isMissingColumnError(error: { code?: string; message?: string }) {
  return error.code === '42703' || /column .* does not exist/i.test(error.message || '');
}

async function findSource(sourceHandle: string): Promise<{ id: string; column: SourceColumn }> {
  const normalizedHandle = sourceHandle.replace(/^@/, '').trim();
  let sourceColumn: SourceColumn = 'screen_name';
  let lookup = await supabase
    .from('sources')
    .select('id')
    .eq(sourceColumn, normalizedHandle)
    .maybeSingle();

  if (lookup.error && isMissingColumnError(lookup.error)) {
    sourceColumn = 'handle';
    lookup = await supabase
      .from('sources')
      .select('id')
      .eq(sourceColumn, normalizedHandle)
      .maybeSingle();
  }

  if (lookup.error) {
    throw new Error(`Failed to find source @${normalizedHandle}: ${lookup.error.message}`);
  }

  if (lookup.data) {
    return { id: lookup.data.id, column: sourceColumn };
  }

  const created = await supabase
    .from('sources')
    .insert({ [sourceColumn]: normalizedHandle } as any)
    .select('id')
    .single();

  if (created.error) {
    throw new Error(`Failed to create source @${normalizedHandle}: ${created.error.message}`);
  }

  return { id: created.data.id, column: sourceColumn };
}

export async function saveTweetsToSupabase(
  sourceHandle: string,
  tweets: ScrapedTweet[],
  analysisLimit = DEFAULT_ANALYSIS_LIMIT,
  onAnalysis?: (tweet: ScrapedTweet, analysis: AIResult) => Promise<void>
): Promise<{ inserted: number; skipped: number; analyzed: number; analyses: Array<{ tweet: ScrapedTweet; analysis: AIResult }> }> {
  if (tweets.length === 0) {
    return { inserted: 0, skipped: 0, analyzed: 0, analyses: [] };
  }

  const source = await findSource(sourceHandle);
  const tweetIds = tweets.map((tweet) => tweet.tweetId);
  const existing = await supabase
    .from('reports')
    .select('tweet_id, category')
    .in('tweet_id', tweetIds);

  if (existing.error) {
    throw new Error(`Failed to check existing tweets for @${sourceHandle}: ${existing.error.message}`);
  }

  const existingReports = new Map(
    (existing.data || []).map((report) => [report.tweet_id, report])
  );
  const newTweets = tweets.filter((tweet) => !existingReports.has(tweet.tweetId));
  const tweetsNeedingAnalysis = tweets.filter((tweet) => {
    const existingReport = existingReports.get(tweet.tweetId);
    return !existingReport || existingReport.category === null;
  });

  const tweetsToAnalyze = tweetsNeedingAnalysis.slice(0, analysisLimit);

  const analyzedTweets = new Map<string, AIResult | null>();
  for (let batchStart = 0; batchStart < tweetsToAnalyze.length; batchStart += 10) {
    const batch = tweetsToAnalyze.slice(batchStart, batchStart + 10);
    if (batchStart > 0) {
      await sleep(ANALYSIS_DELAY_MS);
    }
    const batchResults = await analyzeTweetsBatch(batch.map((tweet) => ({
      id: tweet.tweetId,
      text: tweet.text
    })));
    const resultsById = new Map(batchResults.map((result) => [result.id, result]));

    for (const tweet of batch) {
      const batchResult = resultsById.get(tweet.tweetId);
      const analysis = batchResult ? toAnalysisResult(batchResult) : null;
      analyzedTweets.set(tweet.tweetId, analysis);
      console.log(`[AI] ${tweet.tweetId}: ${JSON.stringify({
        is_news: analysis?.is_news ?? false,
        category: analysis?.category ?? null,
        summaryTr: analysis?.summaryTr ?? null
      })}`);
      if (analysis?.is_news && onAnalysis) {
        await onAnalysis(tweet, analysis);
      }
    }
  }

  const reports = newTweets
    .filter((tweet) => analyzedTweets.get(tweet.tweetId)?.is_news === true)
    .map((tweet) => {
    const analysis = analyzedTweets.get(tweet.tweetId) ?? null;

    return {
      source_id: source.id,
      tweet_id: tweet.tweetId,
      content: tweet.text,
      tweet_url: tweet.url,
      tweet_created_at: tweet.createdAt,
      category: analysis?.category ?? null,
      is_actionable: analysis?.isActionable ?? null,
      summary: analysis?.summaryTr ?? null,
      entities: analysis ?? null,
      confidence_score: analysis?.confidenceScore ?? null,
      analyzed_at: analysis ? new Date().toISOString() : null
    };
    });

  let inserted = 0;
  if (reports.length > 0) {
    const result = await supabase
      .from('reports')
      .upsert(reports, { onConflict: 'tweet_id', ignoreDuplicates: true })
      .select('tweet_id');

    if (result.error) {
      throw new Error(`Failed to save tweets for @${sourceHandle}: ${result.error.message}`);
    }

    inserted = result.data?.length || 0;
  }

  for (const tweet of tweetsToAnalyze
    .filter((tweet) => existingReports.has(tweet.tweetId))
  ) {
    const analysis = analyzedTweets.get(tweet.tweetId);
    if (!analysis?.is_news) {
      continue;
    }

    const update = await supabase
      .from('reports')
      .update({
        category: analysis.category,
        is_actionable: analysis.isActionable,
        summary: analysis.summaryTr,
        entities: analysis,
        confidence_score: analysis.confidenceScore,
        analyzed_at: new Date().toISOString()
      })
      .eq('tweet_id', tweet.tweetId);

    if (update.error) {
      throw new Error(`Failed to update analysis for tweet ${tweet.tweetId}: ${update.error.message}`);
    }
  }

  return {
    inserted,
    skipped: tweets.length - inserted,
    analyzed: tweetsToAnalyze.length,
    analyses: tweetsToAnalyze.flatMap((tweet) => {
      const analysis = analyzedTweets.get(tweet.tweetId);
      return analysis ? [{ tweet, analysis }] : [];
    })
  };
}
