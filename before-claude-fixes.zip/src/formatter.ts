export function formatTelegramHtml(analysis: any, sources: Array<any>): string {
  const { category, subjectName, subjectRole, fromClub, toClub, primaryClub, statusDescription, confidenceScore, summaryTr } = analysis;

  let sourcesBlock = '';
  if (sources.length === 1) {
    const s = sources[0];
    sourcesBlock = `• <b>Kaynak:</b> <a href="${s.tweetUrl}">@${s.username}</a> (Tier ${s.tier} | ${s.alignment})`;
  } else {
    sourcesBlock = `• <b>Doğrulayan Kaynaklar (${sources.length}):</b>\n` +
      sources.map(s => `  ▫️ <a href="${s.tweetUrl}">@${s.username}</a> (Tier ${s.tier} | ${s.alignment})`).join('\n');
  }

  const primarySourceLink = sources[0]
    ? `\n🔗 <a href="${sources[0].tweetUrl}">Habere/Tweete Git</a>`
    : '';

  const clubName = primaryClub || toClub || fromClub || null;
  const roleLabel = subjectRole === 'Teknik Direktör' ? 'Teknik Direktör' :
                    subjectRole === 'Yönetici' ? 'Yönetici' : 'Oyuncu';

  if (category === 'TRANSFER' || category === 'CONTRACT_EXTENSION') {
    let clubLine = '';
    if (fromClub && toClub) {
      clubLine = `• <b>Kulüpler:</b> ${fromClub} ➔ ${toClub}\n`;
    } else if (toClub) {
      clubLine = `• <b>Kulüp:</b> ➔ ${toClub}\n`;
    } else if (fromClub) {
      clubLine = `• <b>Kulüp:</b> ${fromClub} (Ayrılık)\n`;
    } else if (clubName) {
      clubLine = `• <b>Kulüp:</b> ${clubName}\n`;
    }

    return `<b>TRANSFER | Güven: %${confidenceScore}</b>\n` +
           `• <b>${roleLabel}:</b> ${subjectName}\n` +
           `${clubLine}` +
           `• <b>Durum:</b> ${statusDescription || summaryTr}\n` +
           `${sourcesBlock}` +
           primarySourceLink;
  }

  const categoryTitles: Record<string, string> = {
    INJURY: 'SAKATLIK BİLGİSİ',
    SQUAD_STATUS: 'KADRO BİLGİSİ',
    SUSPENSION: 'CEZA BİLGİSİ',
    MANAGER_STAFF: 'TEKNİK HEYET / YÖNETİM'
  };

  const title = categoryTitles[category] || 'GELİŞME';
  const clubLine = clubName ? `• <b>Kulüp:</b> ${clubName}\n` : '• <b>Kulüp:</b> Belirtilmedi\n';

  return `<b>${title} | Güven: %${confidenceScore}</b>\n` +
         `• <b>${roleLabel}:</b> ${subjectName}\n` +
         `${clubLine}` +
         `• <b>Gelişme:</b> ${statusDescription || summaryTr}\n` +
         `${sourcesBlock}` +
         primarySourceLink;
}