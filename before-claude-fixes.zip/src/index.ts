import 'dotenv/config';
import dotenv from 'dotenv';
import path from 'node:path';
import { fetchTweetsFromUser } from './scraper/twitter.js';
import { saveTweetsToSupabase } from './db/supabase.js';
import { formatTelegramHtml } from './formatter.js';
import { sendTelegramMessage } from './publisher.js';
import { REPORTERS } from './reporters.js';
import { analyzeTweetsBatch, logGeminiSessionCost } from './ai/analyzer.js';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const TWEET_MAX_AGE_MS = 10_800_000;
const SCAN_INTERVAL_MS = 180_000;
const sleep = (ms: number) => new Promise((resolve) => setTimeout(resolve, ms));

async function testScraper() {
  const handles = REPORTERS.map((reporter) => reporter.username);
  const results = await Promise.all(
    handles.map(async (handle) => ({
      handle,
      tweets: await fetchTweetsFromUser(handle)
    }))
  );

  results.forEach(({ handle, tweets }) => {
    console.log(`[RapidAPI] @${handle}: ${tweets.length} tweets`);

    tweets.slice(0, 3).forEach((tweet: any, index: number) => {
      console.log(`[${index + 1}] Text: ${tweet.text ?? ''}`);
      console.log(`    URL: ${tweet.url ?? ''}`);
      console.log(`    Date: ${tweet.createdAt ?? ''}`);
    });
  });

  const targetResult = results.find(({ handle }) => handle === 'yagosabuncuoglu');
  const anotherHandleSucceeded = results.some(
    ({ handle, tweets }) => handle !== 'yagosabuncuoglu' && tweets.length > 0
  );

  if (targetResult && targetResult.tweets.length === 0 && anotherHandleSucceeded) {
    console.warn('[RapidAPI] Account data pending cache or restricted by provider: @yagosabuncuoglu');
  }

  for (const { handle, tweets } of results) {
    try {
      const freshTweets = tweets.filter((tweet) => {
        try {
          const tweetTimestamp = Number(BigInt(tweet.tweetId) >> 22n) + 1288834974657;
          const tweetDate = new Date(tweetTimestamp);
          const ageMs = Date.now() - tweetTimestamp;
          const ageMinutes = Math.floor(ageMs / 60_000);
          const isFresh = ageMs >= 0 && ageMs <= TWEET_MAX_AGE_MS;
          console.log(`[Zaman Kontrolü] Tweet Tarihi: ${tweetDate.toISOString()} | Yaş: ${ageMinutes} dk -> ${isFresh ? 'İŞLENECEK' : 'ESKİ (ATLANDI)'}`);
          if (!isFresh) {
            console.log(`[ESKİ TWEET ATLANDI] ID: ${tweet.tweetId} (${(ageMs / 3_600_000).toFixed(1)} saat önce)`);
          }
          return isFresh;
        } catch {
          console.warn(`[Zaman Kontrolü] Tweet ID: ${tweet.tweetId} | Geçersiz Snowflake -> ESKİ (ATLANDI)`);
          return false;
        }
      });

      const { inserted, skipped, analyzed } = await saveTweetsToSupabase(
        handle,
        freshTweets,
        freshTweets.length,
        async (tweet, analysis) => {
          // --- EMNİYET KİLİDİ (Çöp, Yorum ve Alakasız Tweet Filtresi) ---
          const allowedCategories = [
            'TRANSFER',
            'CONTRACT_EXTENSION',
            'INJURY',
            'SUSPENSION',
            'SQUAD_STATUS',
            'MANAGER_STAFF'
          ];

          if (
            !analysis ||
            !analysis.is_news ||
            !analysis.isActionable ||
            !analysis.subjectName ||
            analysis.subjectName.trim() === '' ||
            analysis.subjectName.toLowerCase() === 'null' ||
            analysis.subjectName.toLowerCase() === 'belirtilmedi' ||
            (analysis.confidenceScore && analysis.confidenceScore < 70) ||
            !allowedCategories.includes(analysis.category)
          ) {
            console.log(`[FİLTREYE TAKILDI / ATLANDI] Tweet: ${tweet.tweetId} | Sebep: Haber değeri taşımayan veya geçersiz içerik.`);
            return;
          }
          // -------------------------------------------------------------

          const reporter = REPORTERS.find((item) => item.username === handle);
          const source = {
            tweetUrl: tweet.url,
            username: handle,
            tier: reporter?.tier ?? 2,
            alignment: reporter?.alignment ?? 'Bilinmiyor'
          };
          const tweetDraft = formatTelegramHtml(analysis, [source]);

          console.log(`\n[DRAFT TWEET]\n${tweetDraft}`);
          const sourceLine = `<b>Kaynak:</b> <a href="${tweet.url}">@${handle}</a>`;
          const sent = await sendTelegramMessage(tweetDraft, analysis, sourceLine);
          if (sent) {
            console.log(`[Telegram] Tweet ${tweet.tweetId} kanala gönderildi.`);
            console.log(`Canlı haber Telegram'a gönderildi: ${tweet.text.slice(0, 120)}`);
          }
        }
      );
      console.log(`[Supabase] @${handle}: ${inserted} inserted, ${skipped} skipped as duplicates, ${analyzed} analyzed`);
    } catch (error: any) {
      console.error(`[Pipeline] @${handle} atlandı:`, error.message);
      continue;
      }
  }

  logGeminiSessionCost();
}

async function runContinuously(): Promise<void> {
  while (true) {
    try {
      await testScraper();
    } catch (error: any) {
      console.error('[DÖNGÜ] Tarama sırasında beklenmeyen hata:', error.message);
    }

    console.log('[DÖNGÜ] Tarama tamamlandı. 3 dakika sonra tekrar taranacak...');
    await sleep(SCAN_INTERVAL_MS);
  }
}

async function runBatchMockTest(): Promise<void> {
  const mockTweets = [
    {
      id: 'mock-transfer-001',
      text: 'Fenerbahçe, orta saha oyuncusu için kulübüyle transfer görüşmelerinde sona geldi.'
    },
    {
      id: 'mock-joke-002',
      text: 'Bu maçta hakem yine ne yaptığını bilmiyor, tribünde herkes gülüyor.'
    },
    {
      id: 'mock-injury-003',
      text: 'Galatasaray, yıldız oyuncusunun sakatlığı nedeniyle tedavi sürecine başladığını açıkladı.'
    }
  ];

  try {
    const results = await analyzeTweetsBatch(mockTweets);
    console.log(`[TEST_RESULT] Gemini batch yanıtı: ${JSON.stringify(results)}`);
    results.forEach((result) => {
      console.log(`[TEST_RESULT] ${result.id} is_news=${result.is_news}`);
    });
  } catch (error: any) {
    console.error(`[TEST_RESULT] Mock batch testi başarısız: ${error.message}`);
  }
}

runBatchMockTest().then(() => runContinuously());