import { execFile } from 'child_process';
import { promisify } from 'util';
import path from 'path';
import dotenv from 'dotenv';

dotenv.config({ path: path.resolve(process.cwd(), '.env') });

const execFileAsync = promisify(execFile);
const RAPID_API_KEY = process.env.RAPIDAPI_KEY;

if (!RAPID_API_KEY) {
  throw new Error('RAPIDAPI_KEY is not defined. Add RAPIDAPI_KEY to the project root .env file.');
}

export interface ScrapedTweet {
  tweetId: string;
  text: string;
  url: string;
  createdAt: string;
  inReplyToStatusId?: string;
}

export async function fetchTweetsFromUser(username: string): Promise<ScrapedTweet[]> {
  const cleanUsername = username.replace(/^@/, '').trim();
  const url = `https://twitter-api45.p.rapidapi.com/timeline.php?screenname=${encodeURIComponent(cleanUsername)}`;

  const args = [
    '--silent',
    '--request', 'GET',
    url,
    '--header', 'x-rapidapi-host: twitter-api45.p.rapidapi.com',
    '--header', `x-rapidapi-key: ${RAPID_API_KEY}`
  ];

  try {
    const { stdout } = await execFileAsync('curl.exe', args, { maxBuffer: 10 * 1024 * 1024 });

    if (!stdout || stdout.trim() === '') {
      console.warn(`Boş yanıt döndü: @${cleanUsername}`);
      return [];
    }

    const data: any = JSON.parse(stdout);
    const rawList = Array.isArray(data.timeline) ? data.timeline : [];
    console.log(`[SCRAPER] @${cleanUsername}: ${rawList.length} raw tweets found`);
    const rawById = new Map<string, any>(rawList.map((tweet: any) => [String(tweet.tweet_id), tweet]));

    const mappedTweets = rawList.map((t: any) => ({
      tweetId: t.tweet_id,
      text: (() => {
        const replyId = t.in_reply_to_status_id || t.reply_to_status_id || t.in_reply_to;
        const parent = replyId ? rawById.get(String(replyId)) : undefined;
        const sameAuthor = parent && String(parent.author?.screen_name || cleanUsername).toLowerCase()
          === String(t.author?.screen_name || cleanUsername).toLowerCase();
        return sameAuthor ? `${parent.text}\n---\n${t.text}` : t.text;
      })(),
      url: `https://x.com/${t.author?.screen_name || cleanUsername}/status/${t.tweet_id}`,
      createdAt: t.created_at,
      inReplyToStatusId: t.in_reply_to_status_id || t.reply_to_status_id || t.in_reply_to
    }));

    return mappedTweets.slice(0, 10);
  } catch (error: any) {
    console.error(`[SCRAPER_ERROR] @${cleanUsername}:`, error.message);
    return [];
  }
}